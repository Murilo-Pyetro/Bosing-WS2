/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bosing.unimed.ws;

import com.bosing.unimed.ws.exceptions.ValidaException;
import com.bosing.unimed.ws.model.Pessoa;
import com.bosing.unimed.ws.service.PessoaService;
import jakarta.jws.WebService;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author muril
 */

@WebService (endpointInterface = "com.bosing.unimed.ws.interfaces.PessoaWebServiceImp")
public class PessoaWebServiceImp {
    
    public ArrayList<Pessoa> findlivro(String nome) {
        PessoaService pessoaService = new PessoaService();
        return pessoaService.fiPessoa();
    }

  
    public ArrayList<Pessoa> listAll() throws SQLException {
      PessoaService pessoaService = new PessoaService();
        return pessoaService.lisAll();
    }
    
    public Pessoa findById(int id) throws ValidaException  {
             PessoaService pessoaService = new PessoaService();
             return pessoaService.findById(id);   
    }

    public Pessoa insert(Pessoa pessoa) throws ValidaException{
        PessoaService pessoaService = new PessoaService();
        
        return pessoaService.insert(pessoa);
    }

    
    public void update(int id){
        PessoaService pessoaService = new PessoaService();
    }

    public void delete(int id) {
      PessoaService pessoaService = new PessoaService();
     }
    
}
