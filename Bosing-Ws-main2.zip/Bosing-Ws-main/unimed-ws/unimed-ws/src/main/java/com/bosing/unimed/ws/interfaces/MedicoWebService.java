/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.bosing.unimed.ws.interfaces;

import com.bosing.unimed.ws.model.Medico;
import jakarta.jws.WebMethod;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author muril
 */
public interface MedicoWebService {
   
   @WebMethod
   Medico findById(int id) throws SQLException;
   
   
   @WebMethod
   Medico inserir(Medico medico) throws SQLException;
   
   @WebMethod
   Medico atualizar(Medico medico)throws SQLException;
   
   @WebMethod
   void deletar (int id);
    
}
